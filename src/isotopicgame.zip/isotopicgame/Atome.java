/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package isotopicgame;

/**
 *
 * @author jvere
 */
public class Atome {
    private int numMasse;

    public Atome(int numMasse) {
        this.numMasse = numMasse;
        
    }
    
    

    public int getnumMasse() {
        return numMasse;
    }


    
    
}
