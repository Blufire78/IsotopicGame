/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package isotopicgame;

import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author jvere
 */
public class Grille {

    private int taille = 100;
    private Atome[][] grille = new Atome[taille][taille];

    public Grille(int taille) {
        this.taille = taille;

    }
    

    public void afficher() {

        System.out.println("la grille");
        for (int i = 0; i < taille; i++) {
            for (int j = 0; j < taille; j++) {
                if (grille[i][j] != null) {
                    System.out.print("[" + grille[i][j].getnumMasse() + "]");

                    // un atome est représenté par son nombre de masse
                } else {
                    System.out.print(" " + 0 + " ");

                    // il n'y a pas d'atome le nombre de masse est 0
                }
            }

            System.out.print("\n");
        }
    }

    public void creation() {
        Random gen = new Random();

        Atome atome1 = new Atome(2);
        Atome atome2 = new Atome(4);
        Atome atome3 = new Atome(3);
        Atome atome4 = new Atome(4);
        Atome atome5 = new Atome(2);

        grille[gen.nextInt(taille)][gen.nextInt(taille)] = atome1;
        //grille[gen.nextInt(taille)][gen.nextInt(taille)] = atome2;

        //test de la superposition de deux atomes
        grille[taille - 4][3] = atome3;
        grille[taille - 3][3] = atome4;
        grille[taille - 5][4] = atome5;
    }
    
    public void terrain(){
         Random gen = new Random();
         Atome atome1 = new Atome(2);
         grille[gen.nextInt(taille)][gen.nextInt(taille)] = atome1;
 
    }

    public void déplacementHaut() {
        // le sens de parcour de la grille et opposé à celui du mouvement des atomes pour éviter qu'il se bloque entre eux
        for (int j = 0; j < taille; j++) {
            for (int i = 0; i < taille; i++) {
                int nbatome = 0; //compteur d'atome
                int lignehaut = 0; // colonne la plus haute vide
                int colonnehaut = 0; //ligne la plus haute vide
                for (i = 0; i < taille - 1; i++) {
                    if (grille[i][j] == null) {
                        lignehaut = i;
                        colonnehaut = j;
                        System.out.println(" lignehaut :" + lignehaut + " colonne haut :" + colonnehaut);
                    break;
                    }
                    
                }
                // x et y les coordonnées de l'atome unique
                int x = 0;
                int y = 0;
                for (i = 0; i < taille; i++) {
                    // on compte le nombre d'atome dans la colonne j
                    if (grille[i][j] != null) {
                        nbatome = nbatome + 1;
                        // on prend les coordonnées de l'unique atome si il y en a un seul
                        x = i;
                        y = j;
                    }
                }
                // isolons un cas simple ou l'atome et seul sur sa colonne donc il va automatiquement ne rien recontrer et prends la position la plus haute
                if (nbatome == 1) {
                    System.out.println("le nombre d'atome est :" + nbatome);
                    Atome tamp;
                    tamp = grille[x][y];
                    grille[x][y] = null;
                    grille[lignehaut][colonnehaut] = tamp;
                } // on traite le cas ou l'atome n'est plus seul sans colisions
                else if (nbatome > 1) {
                    System.out.println("le nombre d'atomeS est :" + nbatome);
                    // on cherche à faire bouger tous les atomes 1 par 1
                    for (int z = 0; z <= nbatome; z++) {
                        // la ligne la plus haute est mise à jour à chaque fois que l'on bouge un atome et haut
                        for (i = lignehaut; i < taille; i++) {
                            if (grille[i][j] != null) {
                                Atome tamp;
                                tamp = grille[i][j];
                                grille[i][j] = null;
                                grille[lignehaut][colonnehaut] = tamp;
                                lignehaut = lignehaut + 1;
                                System.out.println("la nouvelle ligne la plus haute est :" + lignehaut + " pour la colonne :" + j);
                            }
                        }

                        System.out.println("les :" + nbatome + " ont bougés");

                        // on traite le cas ou il n'y a pas qu'un seule atome dans la colonne
                    }
                }
            }
        }
    }

    public void déplacementGauche() {
        // le sens de parcour de la grille et opposé à celui du mouvement des atomes pour éviter qu'il se bloque entre eux
        for (int i = 0; i < taille; i++) {
            for (int j = 0; j < taille; j++) {
                int nbatome = 0; //compteur d'atome
                int lignegauche = 0; // colonne la plus à gauche
                int colonnegauche = 0; //ligne la plus haute vide
                for (j = 0; j < taille - 1; j++) {
                    if (grille[i][j] == null) {
                        lignegauche = i;
                        colonnegauche = j;
                        System.out.println(" lignehaut :" + lignegauche + " colonne haut :" + colonnegauche);
                        break;
                    }
                    
                }
                // x et y les coordonnées de l'atome unique
                int x = 0;
                int y = 0;
                for (j = 0; j < taille; j++) {
                    // on compte le nombre d'atome dans la ligen i 
                    if (grille[i][j] != null) {
                        nbatome = nbatome + 1;
                        // on prend les coordonnées de l'unique atome si il y en a un seul
                        x = i;
                        y = j;
                    }
                }
                // isolons un cas simple ou l'atome et seul sur sa colonne donc il va automatiquement ne rien recontrer et prends la position la plus haute
                if (nbatome == 1) {
                    System.out.println("le nombre d'atome est :" + nbatome);
                    Atome tamp;
                    tamp = grille[x][y];
                    grille[x][y] = null;
                    grille[lignegauche][colonnegauche] = tamp;
                } // on traite le cas ou l'atome n'est plus seul sans colisions
                else if (nbatome > 1) {
                    System.out.println("le nombre d'atomeS est :" + nbatome);
                    // on cherche à faire bouger tous les atomes 1 par 1
                    for (int z = 0; z <= nbatome; z++) {
                        // la ligne la plus haute est mise à jour à chaque fois que l'on bouge un atome et haut
                        for (j = colonnegauche; j < taille; j++) {
                            if (grille[i][j] != null) {
                                Atome tamp;
                                tamp = grille[i][j];
                                grille[i][j] = null;
                                grille[lignegauche][colonnegauche] = tamp;
                                colonnegauche = colonnegauche + 1;
                                System.out.println("la nouvelle colonne la plus à droite est :" + colonnegauche + " pour la ligne :" + i);
                            }
                        }

                        System.out.println("les :" + nbatome + " ont bougés");

                        // on traite le cas ou il n'y a pas qu'un seule atome dans la colonne
                    }
                }
            }
        }

    }

    public void déplacementBas() {
        // le sens de parcour de la grille et opposé à celui du mouvement des atomes pour éviter qu'il se bloque entre eux
        
//        int nbcase;
//        nbcase = grille.length;
//        System.out.println("le nombre de case du tableau est :"+ nbcase);
            
                int compteur;
                compteur = taille-1;
                System.out.println("compteur = " + compteur);
        
        
        
        for (int j = compteur; j >= 0; j--) {
            for (int i = compteur; i >= 1; i--) {
                
                //System.out.println("la taille du tableau est "+taille);
                int nbatome = 0; //compteur d'atome
                int lignebas = 0; // colonne la plus basse vide
                int colonnebas = 0; //ligne la plus basse vide

                // transformer en boucle while

                for (i = compteur; i >= 0; i--) {
                    if (grille[i][j] == null) {
                        lignebas = i;
                        colonnebas = j;
                        System.out.println(" ligne bas :" + lignebas + " pour la colonne:" + colonnebas);
                    break;
                    }   
                }
                // x et y les coordonnées de l'atome unique
                int x = 0;
                int y = 0;
                System.out.println("on y arrive 1 = ");
                for (i = 0; i < taille; i++) {
                    
                    // on compte le nombre d'atome dans la colonne j
                    if (grille[i][j] != null) {
                        nbatome = nbatome + 1;
                        System.out.println("on y arrive 3 = ");
                        // on prend les coordonnées de l'unique atome si il y en a un seul
                        x = i;
                        y = j;
                    }
                }
                // isolons un cas simple ou l'atome et seul sur sa colonne donc il va automatiquement ne rien recontrer et prends la position la plus basse
                if (nbatome == 1) {
                    System.out.println("le nombre d'atome est :" + nbatome + "dans la colonne" + j);
                    Atome tamp;
                    tamp = grille[x][y];
                    grille[x][y] = null;
                    grille[lignebas][colonnebas] = tamp;
                } // on traite le cas ou l'atome n'est plus seul sans colisions
                else if (nbatome > 1) {
                    System.out.println("le nombre d'atomeS est :" + nbatome + "dans la colonne " + j);
                    // on cherche à faire bouger tous les atomes 1 par 1
                    for (int z = 0; z <= nbatome; z++) {
                        // la ligne la plus haute est mise à jour à chaque fois que l'on bouge un atome et haut
                        for (i = lignebas; i >= 0; i--) {
                            if (grille[i][j] != null) {
                                Atome tamp;
                                tamp = grille[i][j];
                                grille[i][j] = null;
                                grille[lignebas][colonnebas] = tamp;
                                lignebas = lignebas - 1;
                                System.out.println("la nouvelle ligne la plus haute est :" + lignebas + " pour la colonne :" + j);
                            }
                        }

                        System.out.println("les :" + nbatome + " ont bougés");

                        // on traite le cas ou il n'y a pas qu'un seule atome dans la colonne
                    }
                }
                else;
                System.out.println("pas d'atomme dans la colonne" +j);
                break;
            }
        }
    }

    public void déplacementDroite() {
        // le sens de parcour de la grille et opposé à celui du mouvement des atomes pour éviter qu'il se bloque entre eux
        int compteur;
        compteur = taille -1;
        
        for (int i = 0; i < taille; i++) {
            for (int j = compteur; j>=0; j--) {
                int nbatome = 0; //compteur d'atome
                int lignedroite = 0; // colonne la plus à droite vide
                int colonnedroite = 0; //ligne la plus à doite vide
                for (j = compteur; j >= 0; j--) {
                    if (grille[i][j] == null) {
                        lignedroite = i;
                        colonnedroite = j;
                        System.out.println(" lignedoite :" + lignedroite + " colonnedroite :" + colonnedroite);
                        break;
                    } 
                }
                // x et y les coordonnées de l'atome unique
                int x = 0;
                int y = 0;
                for (j = 0; j < taille; j++) {
                    // on compte le nombre d'atome dans la ligen i 
                    if (grille[i][j] != null) {
                        nbatome = nbatome + 1;
                        // on prend les coordonnées de l'unique atome si il y en a un seul
                        x = i;
                        y = j;
                    }
                }
                // isolons un cas simple ou l'atome et seul sur sa colonne donc il va automatiquement ne rien recontrer et prends la position la plus haute
                if (nbatome == 1) {
                    System.out.println("le nombre d'atome est :" + nbatome);
                    Atome tamp;
                    tamp = grille[x][y];
                    grille[x][y] = null;
                    grille[lignedroite][colonnedroite] = tamp;
                } 
                    // on traite le cas ou l'atome n'est plus seul sans colisions
                else if (nbatome > 1) {
                    System.out.println("le nombre d'atomeS est :" + nbatome);
                    // on cherche à faire bouger tous les atomes 1 par 1
                    for (int z = 0; z <= nbatome; z++) {
                        // la ligne la plus haute est mise à jour à chaque fois que l'on bouge un atome et haut
                        for (j = colonnedroite; j >=0 ; j--) {
                            if (grille[i][j] != null) {
                                Atome tamp;
                                tamp = grille[i][j];
                                grille[i][j] = null;
                                grille[lignedroite][colonnedroite] = tamp;
                                colonnedroite = colonnedroite - 1;
                                System.out.println("la nouvelle colonne la plus à droite est :" + colonnedroite + " pour la ligne :" + i);
                            }
                        }

                        System.out.println("les :" + nbatome + " ont bougés");

                        // on traite le cas ou il n'y a pas qu'un seul atome dans la colonne
                    }
                }
                else;
                System.out.println("il n'y a pas d'atome dans cette colonne  ");
                break;
            }
        }

    }

    public void mouvement() {
        Scanner sc;
        sc = new Scanner(System.in);
        System.out.println("Mouvement Possible \n  haut : 1 \n  bas : 2 \n  droite : 3 \n  gauche : 4");
        int rep = sc.nextInt();

        switch (rep) {

            case (1):
                déplacementHaut();
                break;
            case (2):
                déplacementBas();
                break;
            case (3):
                déplacementDroite();
                break;
            case (4):
                déplacementGauche();
                break;

            default:
                System.out.println("choix non valide");

        }
    }

}
