/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package isotopicgame;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author jvere
 */
public class IsotopicGame {

    /**
     * @param args the command line arguments
     * 
     * 
     * 
     * 
     *  // Reprendre la partie ou créer une nouvelle dans les menu
    // faire apparaitre un élément à chaque tour
    // faire disparaitre les isotope
    // vérifier si la partie et finit (le cas ou il atteint son objectif ou le cas ou le joueur ne peu plus joueur / et fais une pause en faisant une suvegarde du fichier)
    // faire 4 méthode déplacemment haut / bas/droit/gauche
    // rendre la version intermédaire sans interface graphique
    // 
    * 
    * 
    * 
    * 
    * 
    * On ne peut pas faire bouger les atomes par groupe car cela empèche la collision entre eux
    * 
    * 
     */
    public static void main(String[] args) {
        
        boolean fin = false;
        
        while(fin == false){
            
            System.out.println("création de la partie");
            System.out.println("Entrer la taille du tableau");
            Scanner sc;
            sc = new Scanner(System.in);
            int taille = sc.nextInt();
            
            
            Random gen = new Random();
            
            
            // test random
            //int x = gen.nextInt(taille);
            //System.out.println(x);
            
            Grille grille = new Grille(taille);
            grille.creation();  // j'arriva pas à actualiser la taille de la grille
            grille.afficher();
             
            grille.terrain();
            grille.afficher();
            grille.mouvement();
            grille.terrain();
            grille.afficher();
            grille.mouvement();
            grille.terrain();
            grille.afficher();
            grille.mouvement();
            grille.terrain();
            grille.afficher();
            grille.mouvement(); 
            grille.afficher();
            
            
            
        }
        
    }
    
}
