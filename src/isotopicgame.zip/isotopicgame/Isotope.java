/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package isotopicgame;

/**
 *
 * @author jvere
 */
public class Isotope extends Atome{
    private int tempsVie,dateMort;

    public Isotope(int tempsVie, int dateMort, int numMasse, int x, int y) {
        super(numMasse);
        this.tempsVie = tempsVie;
        this.dateMort = dateMort;
    }
    
    
    
}
